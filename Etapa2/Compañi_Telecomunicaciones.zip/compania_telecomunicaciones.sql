-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-11-2020 a las 11:51:42
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `compania_telecomunicaciones`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `RUTCl` varchar(12) NOT NULL COMMENT 'Rut del cliente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `NFactura` int(3) NOT NULL COMMENT 'numero de factura',
  `Fecha` date DEFAULT NULL COMMENT 'Fecha en la que se efectuo la factura',
  `Precio` int(11) DEFAULT NULL COMMENT 'Precio total de la factura',
  `nVentaF` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jefe`
--

CREATE TABLE `jefe` (
  `RUTJe` varchar(12) NOT NULL COMMENT 'Rut del jefe',
  `NombreJE` varchar(20) NOT NULL COMMENT 'Nombre del jefe',
  `ApellidoJe` varchar(20) NOT NULL COMMENT 'Apellido del jefe',
  `ContraseñaJe` varchar(20) NOT NULL COMMENT 'Contraseña del Jefe'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `jefe`
--

INSERT INTO `jefe` (`RUTJe`, `NombreJE`, `ApellidoJe`, `ContraseñaJe`) VALUES
('11.111.111-1', 'NombreJ1', 'ApellidoJ1', '123qwe');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plan`
--

CREATE TABLE `plan` (
  `IdPlan` tinyint(1) NOT NULL COMMENT 'ID de diferenciacion de plan',
  `Precio` smallint(5) DEFAULT NULL COMMENT 'Valor en pesos del plan',
  `Descripcion` varchar(50) DEFAULT NULL COMMENT 'Pequeña descripcioin del contenido del plan ',
  `Nombre` varchar(50) DEFAULT NULL COMMENT 'Nombre del plan '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `plan`
--

INSERT INTO `plan` (`IdPlan`, `Precio`, `Descripcion`, `Nombre`) VALUES
(1, 10000, 'Internet 100 MB/S', 'Internet'),
(2, 25000, 'Television , Internet 100 MB/S', 'Pack duo (Television/Internet)'),
(3, 20000, 'Telefono , Internet 100 MB/S', 'Pack duo (Telefono/Internet)'),
(4, 32767, 'Television, Telefono, Internet 100 MB/S', 'Pack trio (Television/Telefono/Internet)');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vendedor`
--

CREATE TABLE `vendedor` (
  `RUTVen` varchar(12) NOT NULL COMMENT 'Rut Del Vendedor',
  `NombreVen` varchar(20) DEFAULT NULL COMMENT 'Nombre del vendedor',
  `ApellidoVen` varchar(20) DEFAULT NULL COMMENT 'Apellido del vendedor',
  `ContraseñaVen` varchar(20) DEFAULT NULL COMMENT 'Contraseña del vendedor',
  `RUTJe` varchar(12) DEFAULT NULL COMMENT 'Rut del jefe asociado al vendedor'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `vendedor`
--

INSERT INTO `vendedor` (`RUTVen`, `NombreVen`, `ApellidoVen`, `ContraseñaVen`, `RUTJe`) VALUES
('11.111.111-0', 'NombreV0', 'ApellidoV0', '000', '11.111.111-1'),
('11.111.111-2', 'NombreV1', 'ApellidoV1', '123456', '11.111.111-1'),
('11.111.111-3', 'NombreV2', 'ApellidoV2', '456', '11.111.111-1'),
('11.111.111-4', 'NombreV3', 'ApellidoV3', '789', '11.111.111-1'),
('11.111.111-5', 'NombreV4', 'ApellidoV4', '012', '11.111.111-1'),
('11.111.111-6', 'NombreV5', 'ApellidoV5', '345', '11.111.111-1'),
('11.111.111-7', 'NombreV6', 'ApellidoV6', '678', '11.111.111-1'),
('11.111.111-8', 'NombreV7', 'ApellidoV7', '901', '11.111.111-1'),
('11.111.111-9', 'NombreV8', 'ApellidoV8', '234', '11.111.111-1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta`
--

CREATE TABLE `venta` (
  `NVenta` int(5) NOT NULL,
  `DireccionV` varchar(50) DEFAULT NULL,
  `NombreCl` varchar(20) DEFAULT NULL,
  `ApellidoCl` varchar(20) DEFAULT NULL,
  `idplan` tinyint(1) DEFAULT NULL COMMENT 'id del plan aspociado a la venta',
  `RUTClV` varchar(12) DEFAULT NULL,
  `RutVenV` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`RUTCl`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`NFactura`),
  ADD KEY `nVentaF` (`nVentaF`),
  ADD KEY `nVentaF_2` (`nVentaF`);

--
-- Indices de la tabla `jefe`
--
ALTER TABLE `jefe`
  ADD PRIMARY KEY (`RUTJe`);

--
-- Indices de la tabla `plan`
--
ALTER TABLE `plan`
  ADD PRIMARY KEY (`IdPlan`);

--
-- Indices de la tabla `vendedor`
--
ALTER TABLE `vendedor`
  ADD PRIMARY KEY (`RUTVen`),
  ADD KEY `RUTJe` (`RUTJe`);

--
-- Indices de la tabla `venta`
--
ALTER TABLE `venta`
  ADD PRIMARY KEY (`NVenta`),
  ADD KEY `idplan` (`idplan`),
  ADD KEY `RUTCl` (`RUTClV`),
  ADD KEY `RUTCl_2` (`RUTClV`),
  ADD KEY `RutVenV` (`RutVenV`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`nVentaF`) REFERENCES `venta` (`NVenta`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `vendedor`
--
ALTER TABLE `vendedor`
  ADD CONSTRAINT `vendedor_ibfk_1` FOREIGN KEY (`RUTJe`) REFERENCES `jefe` (`RUTJe`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `venta`
--
ALTER TABLE `venta`
  ADD CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`idplan`) REFERENCES `plan` (`IdPlan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `venta_ibfk_2` FOREIGN KEY (`RUTClV`) REFERENCES `cliente` (`RUTCl`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `venta_ibfk_3` FOREIGN KEY (`RutVenV`) REFERENCES `vendedor` (`RUTVen`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
