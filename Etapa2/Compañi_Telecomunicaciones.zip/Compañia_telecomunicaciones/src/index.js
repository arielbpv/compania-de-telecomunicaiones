const bodyparser = require('body-parser');
const express = require('express');
const app = express();
const path = require('path');



//configuracion
app.set('port',process.env.PORT || 3000);
app.set('views', path.join(__dirname,'views'));
app.set('view engine','ejs');

//middleware (funciones que se procesan antes de llegar a rutas)
app.use(express.json()); //transformar formato JSON
app.use(bodyparser.urlencoded({extended: false}));

//Rutas (URL) 
app.use(require('./routes/Vendedor'));
    

//iniciando servidor
app.listen(app.get('port'), () => {
    console.log('servidor en puerto ',app.get('port'))
});