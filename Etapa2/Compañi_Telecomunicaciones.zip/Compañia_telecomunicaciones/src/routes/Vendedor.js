const express = require('express');
const router = express.Router();

const conn = require('../database'); //buscando archivo de configuracion de la base de datos

router.get('/', (req,res) =>{
    //res.render('planes.ejs');
    conn.query('Select * FROM plan', (err,resp,campos) =>{
        res.render('planes.ejs',{
            datos: resp
        });
    });
});
router.get('/admin', (req,res) =>{
    res.render('login.ejs');
});

router.get('/mostrar', (req,res) =>{
    conn.query('Select * FROM vendedor', (err,resp,campos) =>{
        console.log(resp);
        res.render('mostrar.ejs',{
            datos: resp
        });
    });
});

router.post('/ingresar',(req,res) =>{
    //console.log(req.body);
    const{RUTVen, NombreVen, ApellidoVen, ContraseñaVen, RUTJe} =req.body;
    conn.query('INSERT into vendedor SET ? ',{
        RUTVen: RUTVen,
        NombreVen: NombreVen,
        ApellidoVen: ApellidoVen,
        ContraseñaVen: ContraseñaVen,
        RUTJe: RUTJe
    },(err,result) =>{
        if(!err){
            res.redirect('/mostrar');
        }else{
            console.log(err);
        }
    });
});

router.get('/eliminar/:id', (req,res) =>{
    const{ id }= req.params;
    conn.query('DELETE from vendedor WHERE RUTVen = ?',[id], (err,resp,campos) =>{
        if(!err){
            res.redirect('/mostrar');
        }else{
            console.log(err);
        }
    });
});

module.exports = router;