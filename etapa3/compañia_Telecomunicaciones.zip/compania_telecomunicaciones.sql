-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-12-2020 a las 20:49:08
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `compania_telecomunicaciones`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `RUTCl` varchar(12) NOT NULL COMMENT 'Rut del cliente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`RUTCl`) VALUES
('00.000.000-0'),
('00.000.000-1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `NFactura` int(3) NOT NULL COMMENT 'numero de factura',
  `Fecha` date DEFAULT NULL COMMENT 'Fecha en la que se efectuo la factura',
  `Precio` int(11) DEFAULT NULL COMMENT 'Precio total de la factura',
  `nVentaF` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jefe`
--

CREATE TABLE `jefe` (
  `RUTJe` varchar(12) NOT NULL COMMENT 'Rut del jefe',
  `NombreJE` varchar(20) NOT NULL COMMENT 'Nombre del jefe',
  `ApellidoJe` varchar(20) NOT NULL COMMENT 'Apellido del jefe',
  `ContraseñaJe` varchar(20) NOT NULL COMMENT 'Contraseña del Jefe'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `jefe`
--

INSERT INTO `jefe` (`RUTJe`, `NombreJE`, `ApellidoJe`, `ContraseñaJe`) VALUES
('11.111.111-1', 'NombreJ1', 'ApellidoJ1', '123qwe'),
('1234', 'a', 'a', '$2a$04$c5qPn5UN5zLj6');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plan`
--

CREATE TABLE `plan` (
  `IdPlan` tinyint(1) NOT NULL COMMENT 'ID de diferenciacion de plan',
  `Precio` smallint(5) DEFAULT NULL COMMENT 'Valor en pesos del plan',
  `Descripcion` varchar(50) DEFAULT NULL COMMENT 'Pequeña descripcioin del contenido del plan ',
  `Nombre` varchar(50) DEFAULT NULL COMMENT 'Nombre del plan ',
  `href` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `plan`
--

INSERT INTO `plan` (`IdPlan`, `Precio`, `Descripcion`, `Nombre`, `href`) VALUES
(1, 10000, 'Internet 100 MB/S', 'Internet', 'planSoloInternet'),
(2, 25000, 'Television , Internet 100 MB/S', 'Pack duo (Television/Internet)', 'planDuoTvInter'),
(3, 20000, 'Telefono , Internet 100 MB/S', 'Pack duo (Telefono/Internet)', 'planDuoTeleInter'),
(4, 32767, 'Television, Telefono, Internet 100 MB/S', 'Pack trio (Television/Telefono/Internet)', 'planTrio');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sessions`
--

CREATE TABLE `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int(11) UNSIGNED NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `sessions`
--

INSERT INTO `sessions` (`session_id`, `expires`, `data`) VALUES
('02Fv437rErUqxLCqSawIwjTBnudJTKMy', 1607357357, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{\"error\":[\"Missing credentials\"]},\"passport\":{\"user\":\"11.111.112-2\"}}'),
('52LE4OaZ9wh2_X5XMC5qM2Ap3MtUAUhb', 1607367807, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{},\"passport\":{\"user\":\"11.111.112-1\"}}'),
('5KRybuE88GsB6gLQ7qTqawoTz6mQFMwK', 1607352477, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{}}'),
('FEgjueB5CypPfJYzF3e2S5-CCifG-mak', 1607357575, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{},\"passport\":{\"user\":\"11.111.112-2\"}}'),
('Fgr4VC6CfII6Jr1EzO4hdyx9woM40jYY', 1607355766, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{}}'),
('JNdnZGzMKAeR9UPjPq-0uD18F_IyH-tR', 1607365002, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{}}'),
('MT14oQIKDfYndQ2ZC4hzgA1anrFZq4tf', 1607366291, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{},\"passport\":{\"user\":\"11.111.112-1\"}}'),
('NCL484BkEbMXEe31710XrrVKCWvLAIKM', 1607358712, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{}}'),
('Ox3VEahbpCOmoropc9JEuUT2C3tOUxlH', 1607364271, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{}}'),
('RQ2db9RJWuPgC-KPdK_pxcH-FrTs3TF-', 1607369725, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{},\"passport\":{\"user\":\"11.111.112-1\"}}'),
('RrMrxFSKIW8p5etqA6w50InbtIGFYKVa', 1607359272, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{}}'),
('VUxTBl7TAGIgTbVN6WZP6hjcB5Oim6fF', 1607364606, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{},\"passport\":{\"user\":\"11.111.112-1\"}}'),
('WLUBJyLhlZSO73qy46bDHxuFhHo19Pd0', 1607366220, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{},\"passport\":{\"user\":\"11.111.112-2\"}}'),
('WYQgLyY_ASvuWcAOUSNGqnTIUFCDed9w', 1607353177, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{}}'),
('ZVVnnjGgK5jL_6aJmDvGd8M48v7KuIs0', 1607360476, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{},\"passport\":{\"user\":\"11.111.112-1\"}}'),
('eLkmUbyFJweif9RAfKXXr_7nwj3YtUbL', 1607355955, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{}}'),
('f45hBnnRw6SvO5uHF1zSod6jEhlyEMc9', 1607358197, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{}}'),
('l4nXFuTnf0QmLvnxkt72dXE-OSRxsHFq', 1607358629, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{}}'),
('tASWkeOYL2kJi_mNA1yrpwBLqUhtmVYP', 1607352668, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{\"error\":[\"Missing credentials\"]}}'),
('uYj8pJ9CZIHjx0jkD6TOL3nRGqN4YQds', 1607369985, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{\"error\":[\"Missing credentials\"]},\"passport\":{\"user\":\"1234\"}}'),
('vQF3McsYjFVeJ68v1xdNdAW2V163f7R2', 1607352649, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{\"error\":[\"Missing credentials\",\"Missing credentials\",\"Missing credentials\",\"Missing credentials\",\"Missing credentials\",\"Missing credentials\",\"Missing credentials\"]},\"passport\":{\"user\":\"11.111.112-1\"}}'),
('xV0bIlG1tfv709dPFCOn64R-I-szSlbL', 1607352374, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{},\"passport\":{\"user\":\"11.111.112-1\"}}'),
('xeN-H5CNlVdcpcZeG6tj15BZF_S-93bR', 1607356524, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"flash\":{}}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vendedor`
--

CREATE TABLE `vendedor` (
  `idVendedor` int(5) NOT NULL,
  `RUTVen` varchar(12) NOT NULL COMMENT 'Rut Del Vendedor',
  `NombreVen` varchar(20) DEFAULT NULL COMMENT 'Nombre del vendedor',
  `ApellidoVen` varchar(20) DEFAULT NULL COMMENT 'Apellido del vendedor',
  `ContraseñaVen` varchar(20) DEFAULT NULL COMMENT 'Contraseña del vendedor',
  `RUTJe` varchar(12) DEFAULT NULL COMMENT 'Rut del jefe asociado al vendedor'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `vendedor`
--

INSERT INTO `vendedor` (`idVendedor`, `RUTVen`, `NombreVen`, `ApellidoVen`, `ContraseñaVen`, `RUTJe`) VALUES
(1, '11.111.111-0', 'NombreV0', 'ApellidoV0', '000', '11.111.111-1'),
(2, '11.111.111-2', 'NombreV1', 'ApellidoV1', '123456', '11.111.111-1'),
(3, '11.111.111-3', 'NombreV2', 'ApellidoV2', '456', '11.111.111-1'),
(4, '11.111.111-4', 'NombreV3', 'ApellidoV3', '789', '11.111.111-1'),
(5, '11.111.111-5', 'NombreV4', 'ApellidoV4', '012', '11.111.111-1'),
(6, '11.111.111-6', 'NombreV5', 'ApellidoV5', '345', '11.111.111-1'),
(7, '11.111.111-7', 'NombreV6', 'ApellidoV6', '678', '11.111.111-1'),
(8, '11.111.111-8', 'NombreV7', 'ApellidoV7', '901', '11.111.111-1'),
(0, '11.111.111-9', 'NombreV8', 'ApellidoV8', '234', '11.111.111-1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta`
--

CREATE TABLE `venta` (
  `NVenta` int(5) NOT NULL,
  `DireccionV` varchar(50) DEFAULT NULL,
  `NombreCl` varchar(20) DEFAULT NULL,
  `ApellidoCl` varchar(20) DEFAULT NULL,
  `idplan` tinyint(1) DEFAULT NULL COMMENT 'id del plan aspociado a la venta',
  `RUTClV` varchar(12) DEFAULT NULL,
  `RutVenV` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`RUTCl`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`NFactura`),
  ADD KEY `nVentaF` (`nVentaF`);

--
-- Indices de la tabla `jefe`
--
ALTER TABLE `jefe`
  ADD PRIMARY KEY (`RUTJe`);

--
-- Indices de la tabla `plan`
--
ALTER TABLE `plan`
  ADD PRIMARY KEY (`IdPlan`);

--
-- Indices de la tabla `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`session_id`);

--
-- Indices de la tabla `vendedor`
--
ALTER TABLE `vendedor`
  ADD PRIMARY KEY (`RUTVen`),
  ADD KEY `RUTJe` (`RUTJe`);

--
-- Indices de la tabla `venta`
--
ALTER TABLE `venta`
  ADD PRIMARY KEY (`NVenta`),
  ADD UNIQUE KEY `RutVenV_3` (`RutVenV`),
  ADD KEY `idplan` (`idplan`),
  ADD KEY `RUTCl` (`RUTClV`),
  ADD KEY `RUTCl_2` (`RUTClV`),
  ADD KEY `RutVenV` (`RutVenV`),
  ADD KEY `RutVenV_2` (`RutVenV`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `venta`
--
ALTER TABLE `venta`
  MODIFY `NVenta` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`nVentaF`) REFERENCES `venta` (`NVenta`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `vendedor`
--
ALTER TABLE `vendedor`
  ADD CONSTRAINT `vendedor_ibfk_1` FOREIGN KEY (`RUTJe`) REFERENCES `jefe` (`RUTJe`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `venta`
--
ALTER TABLE `venta`
  ADD CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`idplan`) REFERENCES `plan` (`IdPlan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `venta_ibfk_2` FOREIGN KEY (`RUTClV`) REFERENCES `cliente` (`RUTCl`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `venta_ibfk_3` FOREIGN KEY (`RutVenV`) REFERENCES `vendedor` (`RUTVen`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
