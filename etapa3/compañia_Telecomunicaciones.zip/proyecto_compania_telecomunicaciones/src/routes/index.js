const express = require('express');
const passport = require('passport');
const router = express.Router();

const conn = require('../database'); //buscando archivo de configuracion de la base de datos

router.get('/', (req,res) =>{
    //res.redirect('planes.ejs');
    conn.query('Select * FROM plan', (err,resp,campos) =>{
        res.render('planes.hbs',{
            datos: resp
        });
    });
});

router.get('/plantrio', (req,res) =>{
    res.render('plantrio.ejs');
    
    function getRandomArbitrary(min, max) {
        return Math.random() * (10 - 1) + 1;
    }

    const{RUTClV, DireccionV, NombreCl, ApellidoCl} =req.body;
    conn.query('INSERT into venta SET ? ',{
        RUTClV: RUTClV,
        DireccionV: DireccionV,
        NombreCl: NombreCl,
        ApellidoCl: ApellidoCl,
        idplan: 4,
        RUTClV: RUTClV, 
    },(err,result) =>{
        if(!err){
            res.redirect('/mostrar');
        }else{
            console.log(err);
        }
    });


});

router.get('/mostrar', (req,res) =>{
    conn.query('Select * FROM vendedor', (err,resp,campos) =>{
        console.log(resp);
        res.render('mostrar.ejs',{
            datos: resp
        });
    });
});

router.post('/ingresar',(req,res) =>{
    //console.log(req.body);
    const{RUTVen, NombreVen, ApellidoVen, ContraseñaVen, RUTJe} =req.body;
    conn.query('INSERT into vendedor SET ? ',{
        RUTVen: RUTVen,
        NombreVen: NombreVen,
        ApellidoVen: ApellidoVen,
        ContraseñaVen: ContraseñaVen,
        RUTJe: RUTJe
    },(err,result) =>{
        if(!err){
            res.redirect('/mostrar');
        }else{
            console.log(err);
        }
    });
});

router.get('/eliminar/:id', (req,res) =>{
    const{ id }= req.params;
    conn.query('DELETE from vendedor WHERE RUTVen = ?',[id], (err,resp,campos) =>{
        if(!err){
            res.redirect('/mostrar');
        }else{
            console.log(err);
        }
    });
});

//MANEJO DE SESIONES
router.get('/admin', (req,res) =>{
    res.render('login.ejs');
});
router.post('/admin', passport.authenticate('local',{
    successRedirect: "/correcto",
    failureRedirect: "/admin"
}));

router.get('/correcto', (req,res,next)=>{
    if(req.isAuthenticated()) return next();

    res.redirect('/admin');
},(req,res) =>{
    res.redirect('/mostrar')
});
module.exports = router;