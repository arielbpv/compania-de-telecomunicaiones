const express = require('express');
const router = express.Router();

const pool = require('../database');



router.get('/', async (req,res) =>{
    const links = await pool.query('SELECT * FROM plan');
    res.render('links/planes',{ links });

});

router.get('/planSoloInternet',(req,res) =>{
    res.render('links/planSoloInternet');
});
router.get('/planDuoTvInter',(req,res) =>{
    res.render('links/planDuoTvInter');
});
router.get('/planDuoTeleInter',(req,res) =>{
    res.render('links/planDuoTeleInter');
});
router.get('/plantrio',(req,res) =>{
    res.render('links/plantrio');
});
router.get('/vendedores',async(req,res) =>{
    const links = await pool.query('SELECT * FROM vendedor');    
    res.render('links/vendedores',{ links });
});

router.post('/addVenta/:id', async (req,res)=>{
    const{NombreCl,ApellidoCl,DireccionV,RUTClV}=req.body;
    digito= Math.floor(Math.random() * 9)+1;
    rut=digito.toString();
    rutven='11.111.111-'+rut;
    RutVenV =rutven;
    const{ id }= req.params;
    idplan=id;
    NVenta=Math.floor(Math.random() * 100)+1;
    const newLink={
        NVenta,
        DireccionV,
        NombreCl,
        ApellidoCl,
        idplan,
        RUTClV,
        RutVenV
    };
    await pool.query('INSERT INTO venta set ?', [newLink]);
    req.flash('success','Venta agregada correctamente');
    res.redirect('/links');
});
router.get('/addVendedores',(req,res) =>{
    res.render('links/add');
});
router.post('/addVendedores', async (req,res)=>{
    const{RUTVen,NombreVen,ApellidoVen,ContraseñaVen,RUTJe}=req.body;
    const{ id }= req.params;
    const newLink={
        RUTVen,
        NombreVen,
        ApellidoVen,
        ContraseñaVen,
        RUTJe
    };
    await pool.query('INSERT INTO vendedor set ?', [newLink]);
    req.flash('success','Vendedor agregado correctamente');
    res.redirect('/links/vendedores');
});
router.get('/delete/:id', async(req,res) =>{
    const {id} = req.params;
    await pool.query('DELETE FROM vendedor WHERE idVendedor=?',[id]);
    req.flash('success','Vendedor eliminado correctamente');
    res.redirect('/links/vendedores');
    
});
router.get('/edit/:id', async(req,res) =>{
    const {id} = req.params;
    const links = await pool.query('SELECT * FROM vendedor WHERE idVendedor=?',[id])
    res.render('links/edit',{links: links[0]});
    console.log(links[0]);
});
router.post('/edit/:id',async (req, res)=>{
    const{id}= req.params;
    const{RUTVen,NombreVen,ApellidoVen,ContraseñaVen,RUTJe} = req.body;
    const newLink={
        RUTVen,
        NombreVen,
        ApellidoVen,
        ContraseñaVen,
        RUTJe
    };
    await pool.query('UPDATE vendedor set ? WHERE idVendedor=?',[newLink,id]);
    req.flash('success','Vendedor modificado correctamente');
    res.redirect('/links/vendedores');
});
module.exports = router;